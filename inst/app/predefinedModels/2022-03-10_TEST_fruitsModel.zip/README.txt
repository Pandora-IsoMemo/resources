test model with oxcal
